@extends('layoutFeipobol')
@section('formularios')
<div id="NFeria">
        <div class="trasparente wow zoomIn" data-wow-delay="0.3s">


          <div class="contenido">
              <h2 class="h1-responsive font-weight-bold text-center ">NOCHES DE FERIA</h2>
              <p>Muy pronto</p>
          </div>
        </div>
      </div>

@endsection
