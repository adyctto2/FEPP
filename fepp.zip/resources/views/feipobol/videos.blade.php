@extends('layoutFeipobol')
@section('formularios')
<div id="Videos">
  <div class="container">
    <h2 class="h1-responsive font-weight-bold text-center ">GALERIA DE VIDEOS <hr>   </h2>
    <div class="row">
      <div class="col-md-12 wow slideInLeft" data-wow-delay="0.2s" id="principal">
        <iframe  src="https://www.youtube.com/embed/x4K6mLncJuc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
      </div>
    </div>
    <br><br>
  </div>


</div>
@endsection
