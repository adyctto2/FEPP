<?php $__env->startSection('formularios'); ?>
<div id="portfolio" class="section md-padding2 bg-grey">
		<div class="container">
            <div class="row">
                <div class="col-sm-2 fecha">
                    <h5>inicio: <?php echo e($curso1->fecha); ?></h5>
                    <h5>Duracion: <?php echo e($curso1->duracion); ?></h5>
                    <h5>Horaios: <?php echo e($curso1->horarios); ?></h5>
                    <h5>Lugar: <?php echo e($curso1->lugar); ?></h5>
                    <h5>Costo: <?php echo e($curso1->costo); ?></h5>
                    <h5>Expositor: <?php echo e($curso1->expositor); ?></h5>
                    <h5><?php echo e($curso1->certificacion); ?></h5>
                </div>
                <div class="col-sm-7">
                        <h3><?php echo e($curso1->titulo); ?></h3>
                    <img src="<?php echo e(asset('img/cursos/'.$curso1->imagen)); ?>"  class=" images" alt="">
                    <section class="noticia-contenido">
                        <p><?php echo nl2br(e($curso1->descripcion)); ?></p>
                        <h5>Temario</h5>
                        <li><?php echo nl2br(e($curso1->temario)); ?></li>
                    </section>

                </div>
                <hr>
                <div class="col-sm-3 noticias">
                    <div>
										<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('cursoShow', ['id' => $curso->id])); ?>">
                        <div class="blog">
                            <div class="blog-img">
                                <img class="img-responsive" src="<?php echo e(asset('img/cursos/'.$curso->imagen)); ?>" alt="">
                            </div>
                            <div class="blog-content">
                                <h3><?php echo e($curso->titulo); ?></h3>
                            </div>
                        </div>
                    </a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
				</div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>