<?php $__env->startSection('formularios'); ?>
<div id="fotos">
    <section class="gallery-block compact-gallery">
        <div class="">
          <div class="">
              <h2 class="h1-responsive font-weight-bold text-center ">GALERIA DE FOTOS</h2>
          </div>

          <div class="row no-gutters">
            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 item zoom-on-hover wow zoomIn" data-wow-delay="0.3s">
              <a class="lightbox" href="<?php echo e(asset('img/galeria/'.$foto->img)); ?>">
                <img class="img-fluid image" src="<?php echo e(asset('img/galeria/'.$foto->img)); ?>">
                <span class="description">
                  <!-- <span class="description-heading">Lorem Ipsum</span> -->
                  <span class="description-body"><?php echo e($foto->nombre); ?></span>
                </span>
              </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </div>
        </div>

        <!-- <a href=""> Ver todo</a> -->
      </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutFeipobol', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>