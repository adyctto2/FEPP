<?php $__env->startSection('formularios'); ?>
<div id="NFeria">
        <div class="trasparente wow zoomIn" data-wow-delay="0.3s">
      
      
          <div class="contenido">
              <h2 class="h1-responsive font-weight-bold text-center ">Noches de Feria</h2>
              <p>Muy pronto</p>
          </div>
        </div>
      </div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutFeipobol', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>