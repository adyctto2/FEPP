<?php $__env->startSection('formularios'); ?>
<div id="portfolio" class="section md-padding2 bg-grey">
		<div>
            <div class="row">
                <div class="section-header text-center">
                    <h1 class="title"><?php echo e($titulo); ?></h1>
                </div>

                <div class="col-sm-4">
					<div class="menu-form">
											<?php $__currentLoopData = $entidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('entidadeshow', ['id' =>  $entidad->id])); ?>"><?php echo e($entidad->nombre); ?></a>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
				</div>
				<div class="col-sm-2">
                        <img src="<?php echo e(asset('img/entidades/'. $ent->img)); ?>"  class="img-thumbnail" alt="Al-Invest">
				</div>
                <DIV class="col-sm-5 descripcion">
                    <h2><?php echo e($ent->nombre); ?></h2>
                    <P><?php echo e($ent->descripcion); ?></P>
                    <!-- <p><strong>Gerente: </strong><?php echo e($entidad->gerente); ?></p>
                    <p><strong>Presidente: </strong><?php echo e($entidad->presidente); ?></p> -->
                    <p><i class="fa fa-phone" aria-hidden="true"></i><strong>  <?php echo e($ent->telefono); ?> | </strong><i class="fa fa-envelope-o" aria-hidden="true"> </i><strong> <?php echo e($ent-> email); ?></strong> | <i class="fa fa-map-marker" aria-hidden="true"></i>   <?php echo e($ent->direccion); ?></p>
										<a target="_blank" href="<?php echo e($ent->website); ?>"><i class="fa fa-globe" aria-hidden="true"></i></a> | <a target="_blank" href="<?php echo e($ent->facebook); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a> | <a target="_blank"  href="<?php echo e($ent->twitter); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                </DIV>
                <div class="col-sm-1"></div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>