<?php $__env->startSection('formularios'); ?>


<div id="">

  <div class=" container ">
    <div class="contenido">
      <p></p>
        <h2 class="h1-responsive font-weight-bold text-center ">NOTICIAS FEIPOBOL</h2>
        <p></p>
        <p></p>
    </div>
    <div class="row">
      <div class="col-sm-8 wow slideInLeft" data-wow-delay="0.2s">
        <section class="row" >
          <img class="card-img-top" src="<?php echo e(asset('img/noticias/'.$not->imagen)); ?>" alt="Card image cap">

              <div class="col-sm not  " ALIGN="center"><i class="fa fa-calendar" aria-hidden="true"></i> <small class="font-italic"><?php echo e($not->fecha); ?></small></div>
              <div class="col-sm not " ALIGN="center"><i class="fa fa-eye" aria-hidden="true"></i><small class="font-italic"> <?php echo e($variable->total_visitas); ?></small>  vistas</div>
              <div class="col-sm not " ALIGN="center"><i class="fa fa-file-archive-o" aria-hidden="true"></i>  fuente: <small class="font-italic"><a class="rojo" href=""><?php echo e($not->fuente); ?></a></small> </div>
          </section>


            <div class="card-body">
                <h3 class="font-weight-bold" ALIGN="justify"><?php echo e($not->titulo); ?></h3>
                <p class="font-weight-light" ALIGN="justify"><?php echo nl2br(e($not->descripcion)); ?></p>
            </div>

      </div>
      <!-- <div class="col-sm-">

      </div> -->

      <div class="col-sm-4 blo">
        <div class="form-group row wow slideInRight" data-wow-delay="0.2s">
          <div id="globaln">
            <div id="mensajes">
              <?php $__currentLoopData = $notis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('fnoticias', ['id' =>  $noti->id])); ?>">
                  <div class="card-body titulo">
                    <img class="card-img-top" src="<?php echo e(asset('img/noticias/'.$noti->imagen)); ?>" alt="Card image cap">
                      <h1></h1>
                      <h6 class="font-weight-bold" ALIGN="justify"><?php echo e($noti->titulo); ?> </h6>
                        <hr>
                  </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
        </div>
      </div>






    </div>
  </div>
</div>
    <!-- Section heading -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutFeipobol', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>